import math

# Función para calcular el ángulo en grados usando la ley de los cosenos
def calcular_angulo(a, b, c):
    cos_angulo = (a**2 + b**2 - c**2) / (2 * a * b)
    angulo_rad = math.acos(cos_angulo)
    return math.degrees(angulo_rad)

# Función principal para clasificar el triángulo y calcular sus ángulos
def caracterizar_triangulo(a, b, c):
    # Clasificación por lados
    if a == b == c:
        tipo_lados = "Equilátero"
    elif a == b or b == c or a == c:
        tipo_lados = "Isósceles"
    else:
        tipo_lados = "Escaleno"
    
    # Calcular los ángulos
    angulo_A = calcular_angulo(b, c, a)
    angulo_B = calcular_angulo(a, c, b)
    angulo_C = calcular_angulo(a, b, c)
    
    # Clasificación por ángulos
    if angulo_A == 90 or angulo_B == 90 or angulo_C == 90:
        tipo_angulo = "Rectángulo"
    elif angulo_A > 90 or angulo_B > 90 or angulo_C > 90:
        tipo_angulo = "Obtuso"
    else:
        tipo_angulo = "Acutángulo"
    
    # Mostrar resultados
    print(f"\nTriángulo de tipo {tipo_lados} y {tipo_angulo}.")
    print(f"Lados: a = {a}, b = {b}, c = {c}")
    print(f"Ángulos: A = {angulo_A:.2f}°, B = {angulo_B:.2f}°, C = {angulo_C:.2f}°")

# Bucle principal para seguir pidiendo datos
while True:
    # Solicitar al usuario los lados del triángulo
    print("\nIngrese los lados del triángulo (o 0 para salir):")
    a = float(input("Lado a: "))
    if a == 0:
        break
    b = float(input("Lado b: "))
    if b == 0:
        break
    c = float(input("Lado c: "))
    if c == 0:
        break
    
    # Llamar a la función para caracterizar el triángulo
    caracterizar_triangulo(a, b, c)

print("\n¡Programa finalizado!")
