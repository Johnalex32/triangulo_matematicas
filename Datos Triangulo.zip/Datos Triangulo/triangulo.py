import math

# Función que calcula el ángulo en grados usando la ley de los cosenos
def calcular_angulo(a, b, c):
    cos_angulo = (a**2 + b**2 - c**2) / (2 * a * b)
    angulo_rad = math.acos(cos_angulo)  # Ángulo en radianes
    angulo_grados = math.degrees(angulo_rad)  # Convertimos a grados
    return angulo_grados

# Función para clasificar el triángulo
def clasificar_triangulo(lados):
    a, b, c = lados
    
    # Comprobamos si los lados forman un triángulo válido (la suma de dos lados debe ser mayor que el tercero)
    
    
    # Clasificación por lados
    if a == b == c:
        tipo_lados = "Equilátero"
    elif a == b or b == c or a == c:
        tipo_lados = "Isósceles"
    else:
        tipo_lados = "Escaleno"
    
    # Calculamos los ángulos usando la ley de los cosenos
    angulo_A = calcular_angulo(b, c, a)
    angulo_B = calcular_angulo(a, c, b)
    angulo_C = calcular_angulo(a, b, c)
    
    # Clasificación por ángulos
    if angulo_A == 90 or angulo_B == 90 or angulo_C == 90:
        tipo_angulo = "Rectángulo"
    elif angulo_A > 90 or angulo_B > 90 or angulo_C > 90:
        tipo_angulo = "Obtuso"
    else:
        tipo_angulo = "Acutángulo"
    
    # Resultado final
    return (f"Triángulo de tipo {tipo_lados} y {tipo_angulo}.\n"
            f"Lados: a = {a}, b = {b}, c = {c}\n"
            f"Ángulos: A = {angulo_A:.2f}°, B = {angulo_B:.2f}°, C = {angulo_C:.2f}°")

# Función principal
def main():
    # Entrada de los lados del triángulo
    try:
        a = float(input("Ingrese el lado A del triángulo: "))
        b = float(input("Ingrese el lado B del triángulo: "))
        c = float(input("Ingrese el lado C del triángulo: "))
        
        # Llamamos a la función para clasificar el triángulo y obtener los resultados
        resultado = clasificar_triangulo([a, b, c])
        print(resultado)
        
    except ValueError:
        print("Por favor, ingrese valores numéricos válidos.")

# Ejecutar el programa
if __name__ == "__main__":
    main()
